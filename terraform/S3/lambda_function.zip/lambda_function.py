import os
import requests

def lambda_handler(event, context):
    # Extraer detalles del evento
    records = event['Records']
    for record in records:
        bucket_name = record['s3']['bucket']['name']
        object_key = record['s3']['object']['key']

        # Formar el mensaje
        message = f"Nuevo objeto subido:\nBucket: {bucket_name}\nArchivo: {object_key}"

        # Enviar mensaje a Telegram
        send_message_to_telegram(message)

    return {"statusCode": 200}

def send_message_to_telegram(message):
    token = os.environ['TELEGRAM_TOKEN']
    chat_id = os.environ['TELEGRAM_CHAT_ID']
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {"chat_id": chat_id, "text": message}
    response = requests.post(url, json=payload)
    response.raise_for_status()